All patches to bundles will reside here.

e.g. patches
        |- p1
            |- patch.jar
            |- patch-fragment.jar